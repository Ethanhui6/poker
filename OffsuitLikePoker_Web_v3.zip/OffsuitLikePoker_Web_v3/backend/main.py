from fastapi import FastAPI, Depends, HTTPException, Header, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
import secrets, json

from db import Base, engine, get_db
from models import User, Room, Hand, Action
from auth import hash_password, verify_password, create_access_token, decode_token
from realtime import hub

Base.metadata.create_all(bind=engine)

app = FastAPI(title="OffsuitLikePoker API")

# Dev CORS for Vite
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class RegisterIn(BaseModel):
    username: str
    password: str

class LoginIn(BaseModel):
    username: str
    password: str

class CreateRoomIn(BaseModel):
    max_seats: int = 6

class PostActionIn(BaseModel):
    room_id: int
    hand_id: int
    action_type: str
    amount: int = 0

def get_current_user_id(authorization: str | None) -> int:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.split(" ", 1)[1]
    try:
        payload = decode_token(token)
        uid = payload.get("user_id")
        if not uid:
            raise ValueError("no user_id")
        return int(uid)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.get("/api/health")
def health():
    return {"ok": True}

@app.post("/api/register")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if db.query(User).filter(User.username == data.username).first():
        raise HTTPException(status_code=400, detail="Username already exists")
    u = User(username=data.username, password_hash=hash_password(data.password))
    db.add(u)
    db.commit()
    db.refresh(u)
    return {"id": u.id, "username": u.username}

@app.post("/api/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.username == data.username).first()
    if not u or not verify_password(data.password, u.password_hash):
        raise HTTPException(status_code=400, detail="Invalid credentials")
    token = create_access_token({"user_id": u.id})
    return {"access_token": token}

@app.get("/api/me")
def me(db: Session = Depends(get_db), authorization: str | None = Header(default=None)):
    uid = get_current_user_id(authorization)
    u = db.query(User).filter(User.id == uid).first()
    if not u:
        raise HTTPException(status_code=404, detail="User not found")
    return {"id": u.id, "username": u.username}

def _gen_room_code() -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(6))

@app.post("/api/rooms")
def create_room(data: CreateRoomIn, db: Session = Depends(get_db), authorization: str | None = Header(default=None)):
    uid = get_current_user_id(authorization)
    if data.max_seats not in (6, 9):
        raise HTTPException(status_code=400, detail="max_seats must be 6 or 9")
    code = _gen_room_code()
    while db.query(Room).filter(Room.room_code == code).first():
        code = _gen_room_code()

    r = Room(room_code=code, host_user_id=uid, max_seats=data.max_seats)
    db.add(r)
    db.commit()
    db.refresh(r)

    h = Hand(room_id=r.id, hand_no=1, payload_json=json.dumps({"board": [], "hero": []}))
    db.add(h)
    db.commit()
    db.refresh(h)

    return {"room_id": r.id, "room_code": r.room_code, "max_seats": r.max_seats, "hand_id": h.id}

@app.get("/api/rooms/{room_code}")
def get_room(room_code: str, db: Session = Depends(get_db), authorization: str | None = Header(default=None)):
    _ = get_current_user_id(authorization)
    r = db.query(Room).filter(Room.room_code == room_code).first()
    if not r:
        raise HTTPException(status_code=404, detail="Room not found")
    h = db.query(Hand).filter(Hand.room_id == r.id).order_by(Hand.id.desc()).first()
    return {"room_id": r.id, "room_code": r.room_code, "max_seats": r.max_seats, "hand_id": (h.id if h else None)}

@app.post("/api/actions")
def post_action(data: PostActionIn, db: Session = Depends(get_db), authorization: str | None = Header(default=None)):
    uid = get_current_user_id(authorization)
    if data.action_type not in ("fold", "check", "call", "bet", "raise", "allin"):
        raise HTTPException(status_code=400, detail="Invalid action_type")
    a = Action(room_id=data.room_id, hand_id=data.hand_id, user_id=uid, action_type=data.action_type, amount=data.amount)
    db.add(a)
    db.commit()
    db.refresh(a)
    return {"ok": True, "action_id": a.id}

@app.get("/api/actions/{room_id}")
def list_actions(room_id: int, db: Session = Depends(get_db), authorization: str | None = Header(default=None)):
    _ = get_current_user_id(authorization)
    rows = db.query(Action).filter(Action.room_id == room_id).order_by(Action.id.desc()).limit(200).all()
    return [{"id": x.id, "user_id": x.user_id, "action_type": x.action_type, "amount": x.amount, "created_at": x.created_at.isoformat()} for x in rows]

@app.websocket("/ws/room/{room_id}")
async def ws_room(websocket: WebSocket, room_id: str):
    await websocket.accept()
    try:
        hello = await websocket.receive_json()
        max_seats = int(hello.get("max_seats", 6))
        username = str(hello.get("username", "anon"))
        seat_index = int(hello.get("seat_index", 0))
    except Exception:
        await websocket.close(code=1003)
        return

    st = await hub.ensure_room(room_id, max_seats)
    await hub.join(room_id, websocket)

    try:
        if 0 <= seat_index < st["max_seats"]:
            if st["seats"][seat_index] is None:
                st["seats"][seat_index] = username
        await hub.broadcast(room_id, {"type": "state", "state": st})

        while True:
            msg = await websocket.receive_json()
            if msg.get("type") == "action":
                action = msg.get("action", {})
                action["username"] = username
                await hub.apply_action(room_id, action)
            elif msg.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        await hub.leave(room_id, websocket)
