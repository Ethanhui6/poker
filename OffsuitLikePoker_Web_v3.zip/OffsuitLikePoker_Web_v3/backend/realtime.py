from __future__ import annotations
from typing import Dict, Any, Set
from fastapi import WebSocket
import asyncio
import time

# Prototype realtime hub: in-memory only.
# Production: move to Redis + server-authoritative poker engine.
class RoomHub:
    def __init__(self) -> None:
        self.rooms: Dict[str, Dict[str, Any]] = {}
        self.sockets: Dict[str, Set[WebSocket]] = {}
        self.lock = asyncio.Lock()

    def _default_state(self, room_id: str, max_seats: int) -> Dict[str, Any]:
        return {
            "room_id": room_id,
            "max_seats": max_seats,
            "seats": [None] * max_seats,
            "hand_no": 1,
            "board": [{"rank":"K","suit":"♦︎"},{"rank":"7","suit":"♣︎"},{"rank":"2","suit":"♥︎"}],
            "turn": {"rank":"J","suit":"♠︎"},
            "river": {"rank":"3","suit":"♦︎"},
            "last_action": None,
            "updated_at": time.time(),
        }

    async def ensure_room(self, room_id: str, max_seats: int) -> Dict[str, Any]:
        async with self.lock:
            if room_id not in self.rooms:
                self.rooms[room_id] = self._default_state(room_id, max_seats)
                self.sockets[room_id] = set()
            return self.rooms[room_id]

    async def join(self, room_id: str, ws: WebSocket) -> None:
        async with self.lock:
            self.sockets.setdefault(room_id, set()).add(ws)

    async def leave(self, room_id: str, ws: WebSocket) -> None:
        async with self.lock:
            self.sockets.get(room_id, set()).discard(ws)

    async def broadcast(self, room_id: str, msg: Dict[str, Any]) -> None:
        async with self.lock:
            sockets = list(self.sockets.get(room_id, set()))
        dead = []
        for ws in sockets:
            try:
                await ws.send_json(msg)
            except Exception:
                dead.append(ws)
        if dead:
            async with self.lock:
                for ws in dead:
                    self.sockets.get(room_id, set()).discard(ws)

    async def apply_action(self, room_id: str, action: Dict[str, Any]) -> Dict[str, Any]:
        async with self.lock:
            st = self.rooms[room_id]
            st["last_action"] = action
            st["updated_at"] = time.time()
        await self.broadcast(room_id, {"type":"state", "state": st})
        return st

hub = RoomHub()
