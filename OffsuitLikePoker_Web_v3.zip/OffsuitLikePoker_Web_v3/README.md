# OffsuitLikePoker Web v3 (Prototype you can extend)

Features implemented:
- Minimal dark UI inspired by modern iOS style (no asset copying)
- Login/Register (JWT)
- Lobby: create room (6-max/9-max), join room by code
- Friend room sync (WebSocket prototype): seats + last action broadcast
- Table interactions:
  - Swipe up to Fold (no fold button)
  - Turn/River peel (scratch) interaction
  - Stats bottom sheet (HUD-like)
  - Action logging (server stores actions; stats sheet shows recent)
- Equity:
  - Monte Carlo equity vs 1 random opponent using a simple but accurate 7-card evaluator

Limitations (prototype):
- WebSocket hub is in-memory; for production use Redis + authoritative poker engine
- Combo likelihood is a placeholder; range inference needs real action->likelihood model
- Stats (VPIP/PFR/3bet etc.) are placeholders; next step is calculating from the action log per player/position

## Run backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

## Run frontend
```bash
cd frontend
npm install
npm run dev
```

Open: http://localhost:5173

## Deploy for phone
- Backend: Render (use `backend/render.yaml`)
- Frontend: Vercel
  - set env `VITE_API_BASE` to your Render backend URL (e.g. https://xxx.onrender.com)
