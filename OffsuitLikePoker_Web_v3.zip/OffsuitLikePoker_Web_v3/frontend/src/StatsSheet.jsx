import React, { useEffect } from "react";

export default function StatsSheet({ open, onClose, stats, equity, combos, actions }){
  useEffect(() => {
    function onKey(e){ if(e.key === "Escape") onClose(); }
    if(open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if(!open) return null;

  return (
    <div className="sheetBack" onMouseDown={onClose}>
      <div className="sheet" onMouseDown={(e)=>e.stopPropagation()}>
        <div className="sheetHandle" />
        <div className="row" style={{marginBottom:6}}>
          <div className="h1" style={{fontSize:18}}>Stats</div>
          <div className="spacer"/>
          <button className="btn" onClick={onClose}>Close</button>
        </div>

        <div className="statRow"><div className="name">Hands</div><div className="value">{stats.hands}</div></div>
        <div className="statRow"><div className="name">VPIP</div><div className="value">{(stats.vpip*100).toFixed(1)}%</div></div>
        <div className="statRow"><div className="name">PFR</div><div className="value">{(stats.pfr*100).toFixed(1)}%</div></div>
        <div className="statRow"><div className="name">3Bet</div><div className="value">{(stats.threeBet*100).toFixed(1)}%</div></div>

        <div style={{height:12}}/>

        <div className="sub">Equity (Hero vs 1 random):</div>
        <div className="statRow"><div className="name">Win / Tie / Lose</div>
          <div className="value">{(equity.win*100).toFixed(1)}% / {(equity.tie*100).toFixed(1)}% / {(equity.lose*100).toFixed(1)}%</div>
        </div>
        <div className="small">Monte Carlo iters: {equity.iters}</div>

        <div style={{height:12}}/>
        <div className="sub">Combo likelihood (prototype placeholder):</div>
        {combos.map((c,i)=>(
          <div key={i} className="statRow">
            <div className="name">{c.hand}</div>
            <div className="value">{(c.p*100).toFixed(1)}%</div>
          </div>
        ))}

        <div style={{height:12}}/>
        <div className="sub">Recent actions (server log, last 200):</div>
        <div className="small">{actions.length ? "" : "No actions yet."}</div>
        {actions.slice(0,8).map(a=>(
          <div key={a.id} className="statRow">
            <div className="name">#{a.id} u{a.user_id}</div>
            <div className="value">{a.action_type}{a.amount ? ` ${a.amount}` : ""}</div>
          </div>
        ))}

        <div style={{height:10}}/>
        <div className="small" style={{textAlign:"center"}}>
          Range inference + full HUD metrics will build on the action log next.
        </div>
      </div>
    </div>
  );
}
