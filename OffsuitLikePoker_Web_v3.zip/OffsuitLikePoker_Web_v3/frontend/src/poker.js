// Minimal Texas Hold'em evaluator (prototype)
// - Evaluates best 5-card hand from 7 cards by enumerating all 5-card combos (21).
// - Monte Carlo equity vs 1 random opponent.
// This is accurate but not optimized. Good enough for UI prototype.

const RANKS = ["2","3","4","5","6","7","8","9","T","J","Q","K","A"];
const RANK_TO_V = Object.fromEntries(RANKS.map((r,i)=>[r,i+2]));
const SUITS = ["♠︎","♥︎","♦︎","♣︎"];

export function fullDeck(){
  const d = [];
  for(const r of RANKS) for(const s of SUITS) d.push({rank:r, suit:s});
  return d;
}

export function cardKey(c){ return c.rank + c.suit; }

function comb5(arr){
  const out = [];
  const n = arr.length;
  for(let a=0;a<n-4;a++)
    for(let b=a+1;b<n-3;b++)
      for(let c=b+1;c<n-2;c++)
        for(let d=c+1;d<n-1;d++)
          for(let e=d+1;e<n;e++)
            out.push([arr[a],arr[b],arr[c],arr[d],arr[e]]);
  return out;
}

function isStraight(valsDesc){
  // valsDesc: unique values sorted desc
  if(valsDesc.length < 5) return null;
  // handle wheel A-5
  const wheel = [14,5,4,3,2];
  const set = new Set(valsDesc);
  if(wheel.every(v=>set.has(v))) return 5; // straight to 5
  for(let i=0;i<=valsDesc.length-5;i++){
    const top = valsDesc[i];
    let ok = true;
    for(let k=1;k<5;k++){
      if(!set.has(top-k)){ ok=false; break; }
    }
    if(ok) return top;
  }
  return null;
}

function score5(cards){
  // returns array for comparison; bigger is better
  const vals = cards.map(c=>RANK_TO_V[c.rank]).sort((a,b)=>b-a);
  const suits = cards.map(c=>c.suit);
  const flush = suits.every(s=>s===suits[0]);

  // counts
  const cnt = new Map();
  for(const v of vals) cnt.set(v, (cnt.get(v)||0)+1);
  const groups = [...cnt.entries()].sort((a,b)=>{
    // sort by count desc then value desc
    if(b[1]!==a[1]) return b[1]-a[1];
    return b[0]-a[0];
  });

  const uniqDesc = [...new Set(vals)].sort((a,b)=>b-a);
  const straightTop = isStraight(uniqDesc);

  if(straightTop && flush){
    // straight flush
    return [8, straightTop];
  }

  if(groups[0][1]===4){
    // quads: [7, quadVal, kicker]
    const quad = groups[0][0];
    const kicker = groups[1][0];
    return [7, quad, kicker];
  }

  if(groups[0][1]===3 && groups[1][1]===2){
    // full house: [6, trips, pair]
    return [6, groups[0][0], groups[1][0]];
  }

  if(flush){
    // flush: [5, highcards...]
    return [5, ...vals];
  }

  if(straightTop){
    // straight: [4, top]
    return [4, straightTop];
  }

  if(groups[0][1]===3){
    // trips: [3, trips, kickers...]
    const trips = groups[0][0];
    const kickers = groups.slice(1).map(x=>x[0]).sort((a,b)=>b-a);
    return [3, trips, ...kickers];
  }

  if(groups[0][1]===2 && groups[1][1]===2){
    // two pair: [2, highPair, lowPair, kicker]
    const p1 = Math.max(groups[0][0], groups[1][0]);
    const p2 = Math.min(groups[0][0], groups[1][0]);
    const kicker = groups[2][0];
    return [2, p1, p2, kicker];
  }

  if(groups[0][1]===2){
    // one pair: [1, pair, kickers...]
    const pair = groups[0][0];
    const kickers = groups.slice(1).map(x=>x[0]).sort((a,b)=>b-a);
    return [1, pair, ...kickers];
  }

  // high card: [0, vals...]
  return [0, ...vals];
}

function cmpScore(a,b){
  const n = Math.max(a.length,b.length);
  for(let i=0;i<n;i++){
    const av = a[i] ?? 0;
    const bv = b[i] ?? 0;
    if(av!==bv) return av-bv;
  }
  return 0;
}

export function bestOf7(cards7){
  let best = null;
  for(const five of comb5(cards7)){
    const sc = score5(five);
    if(!best || cmpScore(sc, best)>0) best = sc;
  }
  return best;
}

function drawWithout(deck, excludeKeys, n){
  const pool = deck.filter(c=>!excludeKeys.has(cardKey(c)));
  // Fisher-Yates partial
  for(let i=pool.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0,n);
}

export function equityVsRandom1(hero2, board0to5, iters=2500){
  const deck = fullDeck();
  const exclude = new Set([...hero2, ...board0to5].map(cardKey));
  let win=0, tie=0, lose=0;

  const needBoard = 5 - board0to5.length;

  for(let t=0;t<iters;t++){
    const opp2 = drawWithout(deck, exclude, 2);
    const ex2 = new Set(exclude);
    opp2.forEach(c=>ex2.add(cardKey(c)));

    const rest = drawWithout(deck, ex2, needBoard);
    const board = board0to5.concat(rest);

    const heroScore = bestOf7(hero2.concat(board));
    const oppScore = bestOf7(opp2.concat(board));
    const c = cmpScore(heroScore, oppScore);
    if(c>0) win++;
    else if(c<0) lose++;
    else tie++;
  }

  const total = win+tie+lose;
  return { win: win/total, tie: tie/total, lose: lose/total, iters: total };
}

// Very simple "combo likelihood" placeholder for prototype.
// Returns a few example combos with normalized weights.
export function guessCombosPlaceholder(){
  const combos = [
    { hand:"AK", p:0.18 },
    { hand:"AQ", p:0.14 },
    { hand:"KQ", p:0.12 },
    { hand:"JJ", p:0.11 },
    { hand:"TT", p:0.10 },
    { hand:"A5s", p:0.08 },
    { hand:"QJs", p:0.07 },
    { hand:"98s", p:0.06 },
    { hand:"random", p:0.14 },
  ];
  const sum = combos.reduce((s,x)=>s+x.p,0);
  return combos.map(x=>({ ...x, p: x.p/sum }));
}
