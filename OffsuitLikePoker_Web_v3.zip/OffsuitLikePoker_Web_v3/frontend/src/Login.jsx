import React, { useState } from "react";
import { api, setToken } from "./api.js";

export default function Login({ onAuthed }){
  const [username, setU] = useState("");
  const [password, setP] = useState("");
  const [msg, setMsg] = useState("");
  const [mode, setMode] = useState("login");
  const [busy, setBusy] = useState(false);

  async function submit(){
    setMsg(""); setBusy(true);
    try{
      if (mode === "register") await api.register(username, password);
      const r = await api.login(username, password);
      setToken(r.access_token);
      onAuthed();
    }catch(e){ setMsg(e.message); }
    finally{ setBusy(false); }
  }

  return (
    <div className="card" style={{padding:16, maxWidth:460, margin:"0 auto"}}>
      <div className="row" style={{marginBottom:10}}>
        <div className="h1">OffsuitLikePoker</div>
        <div className="spacer" />
        <span className="pill">{mode === "login" ? "Login" : "Register"}</span>
      </div>
      <div className="sub" style={{marginBottom:14}}>
        Minimal · swipe-fold · peel turn/river · stats · equity (MC) · rooms (ws prototype)
      </div>

      <div style={{display:"grid", gap:10}}>
        <input className="input" placeholder="username" value={username} onChange={e=>setU(e.target.value)} />
        <input className="input" placeholder="password" type="password" value={password} onChange={e=>setP(e.target.value)} />
        <button className="btn primary" onClick={submit} disabled={busy || !username || !password}>
          {busy ? "..." : (mode === "login" ? "Login" : "Create account")}
        </button>
        <button className="btn" onClick={()=>setMode(mode==="login"?"register":"login")} disabled={busy}>
          {mode === "login" ? "Need an account? Register" : "Have an account? Login"}
        </button>
      </div>

      {msg && <div className="sub" style={{color:"var(--danger)", marginTop:10}}>{msg}</div>}
    </div>
  );
}
