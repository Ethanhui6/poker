import React, { useState } from "react";
import { api } from "./api.js";

export default function Lobby({ me, onLogout, onEnterRoom }){
  const [maxSeats, setMaxSeats] = useState(6);
  const [joinCode, setJoinCode] = useState("");
  const [seatIndex, setSeatIndex] = useState(0);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  async function createRoom(){
    setMsg(""); setBusy(true);
    try{
      const r = await api.createRoom(maxSeats);
      onEnterRoom({ ...r, seat_index: 0 });
    }catch(e){ setMsg(e.message); }
    finally{ setBusy(false); }
  }

  async function joinRoom(){
    setMsg(""); setBusy(true);
    try{
      const r = await api.getRoom(joinCode.trim().toUpperCase());
      onEnterRoom({ ...r, seat_index: seatIndex });
    }catch(e){ setMsg(e.message); }
    finally{ setBusy(false); }
  }

  return (
    <div className="card" style={{padding:16}}>
      <div className="row">
        <div>
          <div className="h1">Lobby</div>
          <div className="sub">{me ? `Logged in as ${me.username}` : "..."}</div>
        </div>
        <div className="spacer"/>
        <button className="btn" onClick={onLogout}>Logout</button>
      </div>

      <div style={{height:14}}/>

      <div className="grid2">
        <div className="card" style={{padding:14}}>
          <div className="sub" style={{marginBottom:10}}>Create Room</div>
          <div className="seg">
            <button className={maxSeats===6 ? "active" : ""} onClick={()=>setMaxSeats(6)}>6-max</button>
            <button className={maxSeats===9 ? "active" : ""} onClick={()=>setMaxSeats(9)}>9-max</button>
          </div>
          <div style={{height:12}}/>
          <button className="btn primary" onClick={createRoom} disabled={busy}>Create</button>
          <div className="small" style={{marginTop:10}}>Creates a room code you can share.</div>
        </div>

        <div className="card" style={{padding:14}}>
          <div className="sub" style={{marginBottom:10}}>Join Room</div>
          <input className="input" placeholder="room code (e.g. ABC123)" value={joinCode} onChange={e=>setJoinCode(e.target.value)} />
          <div style={{height:10}}/>
          <input className="input" type="number" min="0" max="8" value={seatIndex}
            onChange={e=>setSeatIndex(parseInt(e.target.value||"0",10))} placeholder="seat index" />
          <div className="small" style={{marginTop:6}}>0..5 for 6-max, 0..8 for 9-max</div>
          <div style={{height:12}}/>
          <button className="btn primary" onClick={joinRoom} disabled={busy || !joinCode}>Join</button>
        </div>
      </div>

      {msg && <div className="sub" style={{color:"var(--danger)", marginTop:10}}>{msg}</div>}
    </div>
  );
}
