import React, { useEffect, useState } from "react";
import { api, getToken, clearToken } from "./api.js";
import Login from "./Login.jsx";
import Lobby from "./Lobby.jsx";
import Table from "./Table.jsx";

export default function App(){
  const [stage, setStage] = useState(getToken() ? "lobby" : "login");
  const [me, setMe] = useState(null);
  const [room, setRoom] = useState(null);

  useEffect(() => {
    if (!getToken()) return;
    api.me().then(setMe).catch(() => { clearToken(); setStage("login"); });
  }, [stage]);

  function onAuthed(){ setStage("lobby"); }
  function logout(){ clearToken(); setMe(null); setRoom(null); setStage("login"); }

  return (
    <div className="container">
      {stage === "login" && <Login onAuthed={onAuthed} />}
      {stage === "lobby" && (
        <Lobby
          me={me}
          onLogout={logout}
          onEnterRoom={(r)=>{ setRoom(r); setStage("table"); }}
        />
      )}
      {stage === "table" && room && (
        <Table me={me} room={room} onBack={()=>setStage("lobby")} />
      )}
    </div>
  );
}
