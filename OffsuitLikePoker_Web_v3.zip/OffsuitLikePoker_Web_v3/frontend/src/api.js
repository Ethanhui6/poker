const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";

export function setToken(t) { localStorage.setItem("token", t); }
export function getToken() { return localStorage.getItem("token"); }
export function clearToken() { localStorage.removeItem("token"); }

async function request(path, { method="GET", body } = {}) {
  const token = getToken();
  const headers = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}/api${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}

export const api = {
  health: () => request("/health"),
  register: (username, password) => request("/register", { method: "POST", body: { username, password } }),
  login: (username, password) => request("/login", { method: "POST", body: { username, password } }),
  me: () => request("/me"),
  createRoom: (max_seats) => request("/rooms", { method:"POST", body:{ max_seats } }),
  getRoom: (room_code) => request(`/rooms/${room_code}`),
  postAction: (room_id, hand_id, action_type, amount=0) => request("/actions", { method:"POST", body:{ room_id, hand_id, action_type, amount } }),
  listActions: (room_id) => request(`/actions/${room_id}`),
};

export function wsUrl(path){
  const u = new URL(API_BASE);
  u.protocol = u.protocol === "https:" ? "wss:" : "ws:";
  u.pathname = path;
  u.search = "";
  u.hash = "";
  return u.toString();
}
