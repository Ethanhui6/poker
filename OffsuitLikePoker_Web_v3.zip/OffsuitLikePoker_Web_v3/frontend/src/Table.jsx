import React, { useEffect, useMemo, useRef, useState } from "react";
import StatsSheet from "./StatsSheet.jsx";
import { api, wsUrl } from "./api.js";
import { equityVsRandom1, guessCombosPlaceholder } from "./poker.js";

function CardFace({ rank, suit, label }){
  return (
    <div className="cardFace">
      <div className="rank">{rank}{suit}</div>
      {label ? <div className="label">{label}</div> : <div className="label">&nbsp;</div>}
    </div>
  );
}

function PeelCard({ label, card }){
  const [p, setP] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const startRef = useRef(null);

  function onPointerDown(e){
    if(revealed) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    startRef.current = { x: e.clientX, y: e.clientY };
  }
  function onPointerMove(e){
    if(revealed || !startRef.current) return;
    const dx = e.clientX - startRef.current.x;
    const dy = e.clientY - startRef.current.y;
    const pull = Math.max(0, (-dx + dy) / 220);
    setP(Math.min(1, pull));
  }
  function onPointerUp(){
    if(revealed) return;
    if(p > 0.45){ setP(1); setRevealed(true); } else { setP(0); }
    startRef.current = null;
  }

  const overlayStyle = useMemo(() => {
    const w = 62 * (1 - p);
    const h = 88 * (1 - p * 0.65);
    return {
      clipPath: `inset(0px ${Math.max(0, 62 - w)}px ${Math.max(0, 88 - h)}px 0px round 14px)`,
      opacity: revealed ? 0 : 1,
      transition: startRef.current ? "none" : "opacity .18s ease, clip-path .18s ease",
    };
  }, [p, revealed]);

  return (
    <div className="peelWrap"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      style={{touchAction:"none"}}
    >
      <CardFace rank={card.rank} suit={card.suit} label={label} />
      <div className="peelOverlay" style={overlayStyle} />
    </div>
  );
}

export default function Table({ me, room, onBack }){
  const [showStats, setShowStats] = useState(false);
  const [wsState, setWsState] = useState(null);
  const [wsStatus, setWsStatus] = useState("connecting");
  const wsRef = useRef(null);

  const [folded, setFolded] = useState(false);
  const [dragY, setDragY] = useState(0);
  const heroStartRef = useRef(null);

  const [actions, setActions] = useState([]);

  // constant demo cards
  const hero = useMemo(()=>([{rank:"A", suit:"♠︎"}, {rank:"T", suit:"♠︎"}]), []);
  const flop = useMemo(()=>([{rank:"K", suit:"♦︎"},{rank:"7", suit:"♣︎"},{rank:"2", suit:"♥︎"}]), []);
  const turn = useMemo(()=>({rank:"J", suit:"♠︎"}), []);
  const river = useMemo(()=>({rank:"3", suit:"♦︎"}), []);

  const equity = useMemo(() => equityVsRandom1(hero, flop.concat([turn, river]), 2200), [hero, flop, turn, river]);
  const combos = useMemo(() => guessCombosPlaceholder().slice(0,6), []);
  const stats = useMemo(()=>({ hands: 412, vpip: 0.23, pfr: 0.18, threeBet: 0.07 }), []);

  useEffect(() => {
    api.listActions(room.room_id).then(setActions).catch(()=>{});
  }, [room.room_id]);

  useEffect(() => {
    const url = wsUrl(`/ws/room/${room.room_id}`);
    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => {
      setWsStatus("connected");
      ws.send(JSON.stringify({
        max_seats: room.max_seats,
        username: me?.username || "anon",
        seat_index: room.seat_index ?? 0,
      }));
    };
    ws.onclose = () => setWsStatus("closed");
    ws.onerror = () => setWsStatus("error");
    ws.onmessage = (ev) => {
      try{
        const msg = JSON.parse(ev.data);
        if(msg.type === "state") setWsState(msg.state);
      }catch{}
    };

    return () => { try{ ws.close(); }catch{}; };
  }, [room.room_id, room.max_seats, room.seat_index, me?.username]);

  const state = useMemo(() => {
    const fallback = {
      max_seats: room.max_seats,
      seats: Array(room.max_seats).fill(null),
      board: flop,
      turn, river,
      last_action: null,
      hand_no: 1,
    };
    return wsState || fallback;
  }, [wsState, room.max_seats, flop, turn, river]);

  function sendWs(action){
    const ws = wsRef.current;
    if(ws && ws.readyState === 1){
      ws.send(JSON.stringify({ type:"action", action }));
    }
  }

  async function logAction(action_type, amount=0){
    try{
      await api.postAction(room.room_id, room.hand_id, action_type, amount);
      const list = await api.listActions(room.room_id);
      setActions(list);
    }catch{}
  }

  function onHeroDown(e){
    if(folded) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    heroStartRef.current = { y: e.clientY, t: performance.now() };
  }
  function onHeroMove(e){
    if(folded || !heroStartRef.current) return;
    const dy = e.clientY - heroStartRef.current.y;
    setDragY(dy);
  }
  function onHeroUp(){
    if(folded || !heroStartRef.current) return;
    const dy = dragY;
    const dt = Math.max(1, performance.now() - heroStartRef.current.t);
    const vy = dy / dt;
    const upward = -dy;
    const fast = -vy;
    const trigger = Math.max(upward, fast * 220) > 140;

    if(trigger){
      setFolded(true);
      setDragY(-220);
      sendWs({ kind:"fold" });
      logAction("fold", 0);
    }else{
      setDragY(0);
    }
    heroStartRef.current = null;
  }

  const heroStyle = useMemo(() => ({
    transform: `translate3d(0, ${folded ? -220 : dragY}px, 0)`,
    transition: heroStartRef.current ? "none" : "transform .22s cubic-bezier(.2,.9,.2,1)",
    opacity: folded ? 0.12 : 1,
  }), [dragY, folded]);

  const myName = me?.username || "anon";

  return (
    <div className="tableWrap">
      <div className="row">
        <span className="pill">{room.max_seats}-max</span>
        <span className="pill">Room {room.room_code}</span>
        <span className="pill">WS: {wsStatus}</span>
        <div className="spacer" />
        <button className="btn" onClick={()=>setShowStats(true)}>Stats</button>
        <button className="btn" onClick={onBack}>Back</button>
      </div>

      <div className="seats">
        {state.seats.map((name, i)=>(
          <div key={i} className={"seat " + (name===myName ? "me" : "")}>
            Seat {i}: {name || "—"}
          </div>
        ))}
      </div>

      <div className="card tablePanel">
        <div className="cardsRow">
          {flop.map((c, idx)=>(
            <CardFace key={idx} rank={c.rank} suit={c.suit} />
          ))}
          <PeelCard label="TURN" card={turn} />
          <PeelCard label="RIVER" card={river} />
        </div>

        <div className="heroArea">
          <div className={"heroTitle " + (folded ? "folded" : "")}>{folded ? "Folded" : "Hero"}</div>
          <div
            className="heroHand"
            style={heroStyle}
            onPointerDown={onHeroDown}
            onPointerMove={onHeroMove}
            onPointerUp={onHeroUp}
            onPointerCancel={onHeroUp}
          >
            {hero.map((c, idx)=>(
              <CardFace key={idx} rank={c.rank} suit={c.suit} />
            ))}
          </div>

          <div className="row" style={{gap:10}}>
            <button className="btn" onClick={()=>{ sendWs({kind:"check"}); logAction("check",0); }}>Check</button>
            <button className="btn" onClick={()=>{ sendWs({kind:"call"}); logAction("call",0); }}>Call</button>
            <button className="btn primary" onClick={()=>{ sendWs({kind:"bet", amount:50}); logAction("bet",50); }}>Bet 50</button>
            <button className="btn" onClick={()=>{ setFolded(false); setDragY(0); }}>Reset</button>
          </div>

          {state.last_action && (
            <div className="sub" style={{textAlign:"center", marginTop:8}}>
              Last: {state.last_action.username}: {state.last_action.kind}{state.last_action.amount ? ` ${state.last_action.amount}` : ""}
            </div>
          )}

          <div className="small" style={{textAlign:"center", marginTop:6}}>
            Equity now: {(equity.win*100).toFixed(1)}% win (vs 1 random)
          </div>
        </div>
      </div>

      <div className="hint">Swipe up on your hand to Fold · Drag TURN/RIVER to peel · Actions logged + WS room sync</div>

      <StatsSheet
        open={showStats}
        onClose={()=>setShowStats(false)}
        stats={stats}
        equity={equity}
        combos={combos}
        actions={actions}
      />
    </div>
  );
}
